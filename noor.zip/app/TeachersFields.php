<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeachersFields extends Model
{
    //
}
