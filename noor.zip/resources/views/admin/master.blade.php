@include('admin.section.head')
@include('admin.section.header')
@include('admin.section.left-sidebar')
{{--@include('admin.section.mega-menu-bar')--}}
{{--@include('admin.section.right-sidebar')--}}
@yield('content')
@include('admin.section.footer')
@include('admin.section.script')

