@include('web.section.head')
@include('web.section.header')
@include('student.section.user-side')
@yield('content')
@include('web.section.footer')
@include('web.section.script')

