@include('web.section.head')
@include('web.section.header')
@include('user.section.user-side')
@yield('content')
@include('web.section.footer')
@include('web.section.script')

